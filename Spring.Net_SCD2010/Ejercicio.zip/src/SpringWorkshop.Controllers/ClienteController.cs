﻿using System.Collections.Generic;
using System.Web.Mvc;
using SpringWorkshop.ApplicationServices;
using SpringWorkshop.Domain;
using MvcContrib;

namespace SpringWorkshop.Controllers
{
    public class HomeController:Controller
    {
        private readonly string mensaje;

        public HomeController(string mensaje)
        {
            this.mensaje = mensaje;
        }

        public string Index()
       {
           return mensaje;
       }
    }
}
