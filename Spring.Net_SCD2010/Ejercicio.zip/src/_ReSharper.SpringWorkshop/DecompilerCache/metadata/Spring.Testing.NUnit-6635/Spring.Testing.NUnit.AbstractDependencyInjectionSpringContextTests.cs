// Type: Spring.Testing.NUnit.AbstractDependencyInjectionSpringContextTests
// Assembly: Spring.Testing.NUnit, Version=1.3.0.20349, Culture=neutral, PublicKeyToken=65e474d141e25e07
// Assembly location: C:\Users\Snahider\Desktop\SpringWorkshop\Ejercicio\lib\Spring.Net\Spring.Testing.NUnit.dll

using NUnit.Framework;
using Spring.Context;
using Spring.Objects.Factory.Config;
using System.Reflection;

namespace Spring.Testing.NUnit
{
    public abstract class AbstractDependencyInjectionSpringContextTests : AbstractSpringContextTests
    {
        protected IConfigurableApplicationContext applicationContext;
        protected string[] managedVariableNames;
        public bool PopulateProtectedVariables { get; set; }
        public AutoWiringMode AutowireMode { get; set; }
        public bool DependencyCheck { get; set; }
        public int LoadCount { get; }
        protected virtual object ContextKey { get; }
        protected abstract string[] ConfigLocations { get; }
        public void SetDirty();

        [SetUp]
        public virtual void SetUp();

        protected virtual void InjectDependencies();
        protected override IConfigurableApplicationContext LoadContextLocations(string[] locations);
        protected virtual void InitManagedVariableNames();
        protected virtual void InjectProtectedVariables();
        protected virtual void BeforeProtectedVariableInjection(FieldInfo fieldInfo);
        protected virtual void OnSetUp();

        [TearDown]
        public void TearDown();

        protected virtual void OnTearDown();
    }
}
