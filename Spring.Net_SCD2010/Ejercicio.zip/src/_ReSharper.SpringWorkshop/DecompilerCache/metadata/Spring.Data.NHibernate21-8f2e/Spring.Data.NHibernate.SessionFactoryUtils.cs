// Type: Spring.Data.NHibernate.SessionFactoryUtils
// Assembly: Spring.Data.NHibernate21, Version=1.3.0.20349, Culture=neutral, PublicKeyToken=65e474d141e25e07
// Assembly location: C:\Users\Snahider\Desktop\SpringWorkshopFinal\lib\Spring.Net\Spring.Data.NHibernate21.dll

using NHibernate;
using Spring.Dao;
using Spring.Data.Common;
using Spring.Data.Support;

namespace Spring.Data.NHibernate
{
    public abstract class SessionFactoryUtils
    {
        public static readonly int SESSION_SYNCHRONIZATION_ORDER;
        public SessionFactoryUtils();
        public static ISession GetNewSession(ISessionFactory sessionFactory, IInterceptor interceptor);

        public static ISession GetSession(ISessionFactory sessionFactory, IInterceptor entityInterceptor,
                                          IAdoExceptionTranslator adoExceptionTranslator);

        public static ISession GetSession(ISessionFactory sessionFactory, bool allowCreate);
        public static ISession DoGetSession(ISessionFactory sessionFactory, bool allowCreate);
        public static void CloseSession(ISession session);
        public static bool IsSessionTransactional(ISession session, ISessionFactory sessionFactory);
        public static DataAccessException ConvertHibernateAccessException(HibernateException ex);
        public static void ReleaseSession(ISession session, ISessionFactory sessionFactory);
        public static void InitDeferredClose(ISessionFactory sessionFactory);
        public static bool IsDeferredCloseActive(ISessionFactory sessionFactory);
        public static void ProcessDeferredClose(ISessionFactory sessionFactory);
        public static void ApplyTransactionTimeout(ICriteria criteria, ISessionFactory sessionFactory);
        public static void ApplyTransactionTimeout(IQuery query, ISessionFactory sessionFactory);
        public static IDbProvider GetDbProvider(ISessionFactory sessionFactory);
        public static IAdoExceptionTranslator NewAdoExceptionTranslator(ISessionFactory sessionFactory);
    }
}
