﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("CrudScaffolding")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("CrudScaffolding")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("7687ed5d-2157-44b7-bd21-a8c7d7b4fead")]
