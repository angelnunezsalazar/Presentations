
    if exists (select * from dbo.sysobjects where id = object_id(N'Cuentas') and OBJECTPROPERTY(id, N'IsUserTable') = 1) drop table Cuentas

    if exists (select * from dbo.sysobjects where id = object_id(N'hibernate_unique_key') and OBJECTPROPERTY(id, N'IsUserTable') = 1) drop table hibernate_unique_key

    create table Cuentas (
        Id INT not null,
       Numero NVARCHAR(255) null,
       Saldo INT null,
       primary key (Id)
    )

    create table hibernate_unique_key (
         next_hi INT 
    )

    insert into hibernate_unique_key values ( 1 )
