﻿using System;
using System.Configuration;
using FirstSharp.Specs.Steps.Infrastructure;
using HomeBanking.Core;
using HomeBanking.Core.RepositoryInterfaces;
using HomeBanking.Data.NHibernateMaps;
using HomeBanking.Data.Repositories;
using SharpArch.Data.NHibernate;
using SharpArch.Testing.NHibernate;
using TechTalk.SpecFlow;
using WatiN.Core;
using Table = TechTalk.SpecFlow.Table;
using NUnit.Framework;

namespace FirstSharp.Specs.Steps
{
    [Binding]
    public class Transferencia
    {
        [BeforeScenario]
        public void Setup()
        {
            string[] mappingAssemblies = RepositoryTestsHelper.GetMappingAssemblies();
            NHibernateSession.Init(new SimpleSessionStorage(), mappingAssemblies,
                                   new AutoPersistenceModelGenerator().Generate(),
                                   "../../../../app/FirstSharp.Web/NHibernate.config");
        }

        [Given(@"Yo tengo las siguientes Cuentas")]
        public void GivenYoTengoLasSiguientesCuentas(Table table)
        {
            ICuentaRepository cuentaRepository = new CuentaRepository();
            using (NHibernateSession.Current.BeginTransaction())
            {
                foreach (var fila in table.Rows)
                {
                    var cuenta = new Cuenta() { Numero = fila["Numero"] };
                    cuenta.Depositar(int.Parse(fila["Saldo"]));
                    cuentaRepository.SaveOrUpdate(cuenta);
                }
                NHibernateSession.Current.Transaction.Commit();
            }

        }

        [When(@"Yo transfiero (\d+) de dinero desde la primera a la segunda cuenta")]
        public void WhenYoTransfieroDineroDesdeLaPrimeraALaSegundaCuenta(int dinero)
        {
            var rootUrl = new Uri(ConfigurationManager.AppSettings["RootUrl"]);
            var absoluteUrl = new Uri(rootUrl, "/Operaciones/Transferir");
            WebBrowser.Current.GoTo(absoluteUrl);

            WebBrowser.Current.Page<TransferenciaPage>().Transferir("12345678901", "12345678902", dinero);
        }

        [Then(@"El Saldo de mis cuentas debería ser")]
        public void ThenElSaldoDeMisCuentasDeberiaSer(Table table)
        {
            Assert.IsTrue(true);
        }

        [AfterScenario]
        public void TearDown()
        {
            ICuentaRepository cuentaRepository = new CuentaRepository();
            using (NHibernateSession.Current.BeginTransaction())
            {
                var cuentas = cuentaRepository.GetAll();
                foreach (var cuenta in cuentas)
                {
                    cuentaRepository.Delete(cuenta);
                }
                NHibernateSession.Current.Transaction.Commit();
            }

            NHibernateSession.CloseAllSessions();
            NHibernateSession.Reset();
        }

        public class TransferenciaPage : Page
        {
            [FindBy(Name = "DetallesTransferencia.NumeroCuentaOrigen")]
            public TextField NumeroCuentaOrigen;

            [FindBy(Name = "DetallesTransferencia.NumeroCuentaDestino")]
            public TextField NumeroCuentaDestino;

            [FindBy(Name = "DetallesTransferencia.Monto")]
            public TextField Monto;

            [FindBy(Name = "btnTransferir")]
            public Button TransferenciaButton;

            public void Transferir(string numeroCuentaOrigen, string numeroCuentaDestino, int monto)
            {
                NumeroCuentaOrigen.TypeText(numeroCuentaOrigen);
                NumeroCuentaDestino.TypeText(numeroCuentaDestino);
                Monto.TypeText(monto.ToString());
                TransferenciaButton.Click();
            }
        }
    }
}
