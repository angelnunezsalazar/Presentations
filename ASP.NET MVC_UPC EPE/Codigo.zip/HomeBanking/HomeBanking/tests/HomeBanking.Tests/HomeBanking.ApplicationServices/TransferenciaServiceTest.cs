﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HomeBanking.ApplicationServices;
using HomeBanking.Core;
using HomeBanking.Core.RepositoryInterfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace Tests.HomeBanking.ApplicationServices
{
    [TestFixture]
    public class TransferenciaServiceTest
    {
        [Test]
        public void TransferirEnCuentasPersonales_ParametrosValidos_ExpectedBehavior()
        {

            var cuentaOrigen = new CuentaMock();

            var cuentaRepository = MockRepository.GenerateStub<ICuentaRepository>();

            cuentaRepository.Expect(x => x.Obtener("4567-6789-4567")).IgnoreArguments()
                .Return(cuentaOrigen);

            TransferenciaService transferenciaService =
                new TransferenciaService(cuentaRepository);

            DetallesTransferencia detallesTransferencia =
                new DetallesTransferencia();

            transferenciaService.TransferirEnCuentaPersonal(detallesTransferencia);

            Assert.IsTrue(cuentaOrigen.SeHaRealizadoLaTransferencia);


        }

        internal class CuentaMock : Cuenta
        {
            public bool SeHaRealizadoLaTransferencia;

            public override void Transferir(int monto, Cuenta cuentaDestino)
            {
                SeHaRealizadoLaTransferencia = true;
            }
        }
    }
}
