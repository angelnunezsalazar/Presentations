using NUnit.Framework;
using Rhino.Mocks;
using SharpArch.Testing.NUnit;
using System.Collections.Generic;
using SharpArch.Core.PersistenceSupport;
using HomeBanking.Core;
using HomeBanking.ApplicationServices;
using HomeBanking.ApplicationServices.ViewModels;
using HomeBanking.Core.QueryDtos;
using HomeBanking.Core.RepositoryInterfaces;
using Tests.HomeBanking.Core;
 

namespace Tests.HomeBanking.ApplicationServices
{
    [TestFixture]
    public class CuentasManagementServiceTests
    {
        [SetUp]
        public void SetUp() {
            ServiceLocatorInitializer.Init();

            cuentasRepository = 
                MockRepository.GenerateMock<ICuentaRepository>();
            cuentasRepository.Stub(r => r.DbContext)
                .Return(MockRepository.GenerateMock<IDbContext>());
            
            cuentasManagementService =
                new CuentasManagementService(cuentasRepository);
        }

        [Test]
        public void CanGetCuentas() {
            // Establish Context
            Cuenta cuentasToExpect = 
                CuentasInstanceFactory.CreateValidTransientCuentas();

            cuentasRepository.Expect(r => r.Get(1))
                .Return(cuentasToExpect);

            // Act
            Cuenta cuentasRetrieved = 
                cuentasManagementService.Get(1);

            // Assert
            cuentasRetrieved.ShouldNotBeNull();
            cuentasRetrieved.ShouldEqual(cuentasToExpect);
        }

        [Test]
        public void CanGetAllCuentas() {
            // Establish Context
            IList<Cuenta> cuentasToExpect = new List<Cuenta>();

            Cuenta cuentas = 
                CuentasInstanceFactory.CreateValidTransientCuentas();

            cuentasToExpect.Add(cuentas);

            cuentasRepository.Expect(r => r.GetAll())
                .Return(cuentasToExpect);

            // Act
            IList<Cuenta> cuentasRetrieved =
                cuentasManagementService.GetAll();

            // Assert
            cuentasRetrieved.ShouldNotBeNull();
            cuentasRetrieved.Count.ShouldEqual(1);
            cuentasRetrieved[0].ShouldNotBeNull();
            cuentasRetrieved[0].ShouldEqual(cuentas);
        }

        [Test]
        public void CanGetCuentasSummaries() {
            // Establish Context
            IList<CuentasDto> cuentasSummariesToExpect = new List<CuentasDto>();

            CuentasDto cuentasDto = new CuentasDto();
            cuentasSummariesToExpect.Add(cuentasDto);

            cuentasRepository.Expect(r => r.GetCuentasSummaries())
                .Return(cuentasSummariesToExpect);

            // Act
            IList<CuentasDto> cuentasSummariesRetrieved =
                cuentasManagementService.GetCuentasSummaries();

            // Assert
            cuentasSummariesRetrieved.ShouldNotBeNull();
            cuentasSummariesRetrieved.Count.ShouldEqual(1);
            cuentasSummariesRetrieved[0].ShouldNotBeNull();
            cuentasSummariesRetrieved[0].ShouldEqual(cuentasDto);
        }

        [Test]
        public void CanCreateFormViewModel() {
            // Establish Context
            CuentasFormViewModel viewModelToExpect = new CuentasFormViewModel();

            // Act
            CuentasFormViewModel viewModelRetrieved =
                cuentasManagementService.CreateFormViewModel();

            // Assert
            viewModelRetrieved.ShouldNotBeNull();
            viewModelRetrieved.Cuentas.ShouldBeNull();
        }

        [Test]
        public void CanCreateFormViewModelForCuentas() {
            // Establish Context
            CuentasFormViewModel viewModelToExpect = new CuentasFormViewModel();

            Cuenta cuentas = 
                CuentasInstanceFactory.CreateValidTransientCuentas();

            cuentasRepository.Expect(r => r.Get(1))
                .Return(cuentas);

            // Act
            CuentasFormViewModel viewModelRetrieved =
                cuentasManagementService.CreateFormViewModelFor(1);

            // Assert
            viewModelRetrieved.ShouldNotBeNull();
            viewModelRetrieved.Cuentas.ShouldNotBeNull();
            viewModelRetrieved.Cuentas.ShouldEqual(cuentas);
        }

        [Test]
        public void CanSaveOrUpdateValidCuentas() {
            // Establish Context
            Cuenta validCuentas = 
                CuentasInstanceFactory.CreateValidTransientCuentas();

            // Act
            ActionConfirmation confirmation =
                cuentasManagementService.SaveOrUpdate(validCuentas);

            // Assert
            confirmation.ShouldNotBeNull();
            confirmation.WasSuccessful.ShouldBeTrue();
            confirmation.Value.ShouldNotBeNull();
            confirmation.Value.ShouldEqual(validCuentas);
        }

        [Test]
        public void CannotSaveOrUpdateInvalidCuentas() {
            // Establish Context
            Cuenta invalidCuentas = new Cuenta();

            // Act
            ActionConfirmation confirmation =
                cuentasManagementService.SaveOrUpdate(invalidCuentas);

            // Assert
            confirmation.ShouldNotBeNull();
            confirmation.WasSuccessful.ShouldBeFalse();
            confirmation.Value.ShouldBeNull();
        }

        [Test]
        public void CanUpdateWithValidCuentasFromForm() {
            // Establish Context
            Cuenta validCuentasFromForm = 
                CuentasInstanceFactory.CreateValidTransientCuentas();
            
            // Intentionally empty to ensure successful transfer of values
            Cuenta cuentasFromDb = new Cuenta();

            cuentasRepository.Expect(r => r.Get(1))
                .Return(cuentasFromDb);

            // Act
            ActionConfirmation confirmation =
                cuentasManagementService.UpdateWith(validCuentasFromForm, 1);

            // Assert
            confirmation.ShouldNotBeNull();
            confirmation.WasSuccessful.ShouldBeTrue();
            confirmation.Value.ShouldNotBeNull();
            confirmation.Value.ShouldEqual(cuentasFromDb);
            confirmation.Value.ShouldEqual(validCuentasFromForm);
        }

        [Test]
        public void CannotUpdateWithInvalidCuentasFromForm() {
            // Establish Context
            Cuenta invalidCuentasFromForm = new Cuenta();

            // Intentionally empty to ensure successful transfer of values
            Cuenta cuentasFromDb = new Cuenta();

            cuentasRepository.Expect(r => r.Get(1))
                .Return(cuentasFromDb);

            // Act
            ActionConfirmation confirmation =
                cuentasManagementService.UpdateWith(invalidCuentasFromForm, 1);

            // Assert
            confirmation.ShouldNotBeNull();
            confirmation.WasSuccessful.ShouldBeFalse();
            confirmation.Value.ShouldBeNull();
        }

        [Test]
        public void CanDeleteCuentas() {
            // Establish Context
            Cuenta cuentasToDelete = new Cuenta();

            cuentasRepository.Expect(r => r.Get(1))
                .Return(cuentasToDelete);

            // Act
            ActionConfirmation confirmation =
                cuentasManagementService.Delete(1);

            // Assert
            confirmation.ShouldNotBeNull();
            confirmation.WasSuccessful.ShouldBeTrue();
            confirmation.Value.ShouldBeNull();
        }

        [Test]
        public void CannotDeleteNonexistentCuentas() {
            // Establish Context
            cuentasRepository.Expect(r => r.Get(1))
                .Return(null);

            // Act
            ActionConfirmation confirmation =
                cuentasManagementService.Delete(1);

            // Assert
            confirmation.ShouldNotBeNull();
            confirmation.WasSuccessful.ShouldBeFalse();
            confirmation.Value.ShouldBeNull();
        }

        private ICuentaRepository cuentasRepository;
        private ICuentasManagementService cuentasManagementService;
    }
}
