﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using NUnit.Framework;

namespace Tests
{
    public static class Extensions
    {
        public static ViewResult ModelShouldBe<Type>(this ViewResult result, object model)
        {
            Assert.IsInstanceOf(typeof(Type), result.ViewData.Model);
            Assert.AreEqual(model, result.ViewData.Model);
            return result;
        }

        public static ActionResult HasErrors(this ViewResult result)
        {
            Assert.Greater(result.ViewData.ModelState.Count, 0);
            return result;
        }
    }
}
