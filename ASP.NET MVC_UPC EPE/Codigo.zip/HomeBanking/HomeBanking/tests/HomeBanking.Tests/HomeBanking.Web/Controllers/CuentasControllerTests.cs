using MvcContrib.TestHelper;
using NUnit.Framework;
using Rhino.Mocks;
using SharpArch.Testing.NUnit;
using System.Collections.Generic;
using System.Web.Mvc;
using HomeBanking.Core;
using HomeBanking.Core.QueryDtos;
using HomeBanking.ApplicationServices;
using HomeBanking.ApplicationServices.ViewModels;
using HomeBanking.Web.Controllers;
using Tests.HomeBanking.Core;
 

namespace Tests.HomeBanking.Web.Controllers
{
    [TestFixture]
    public class CuentasControllerTests
    {
        [SetUp]
        public void SetUp() {
            ServiceLocatorInitializer.Init();

            cuentasManagementService =
                MockRepository.GenerateMock<ICuentasManagementService>();
            cuentasController = 
                new CuentasController(cuentasManagementService);
        }

        [Test]
        public void CanListCuentas() {
            // Establish Context
            IList<CuentasDto> cuentasSummariesToExpect = new List<CuentasDto>();

            CuentasDto cuentasDto = new CuentasDto();
            cuentasSummariesToExpect.Add(cuentasDto);

            cuentasManagementService.Expect(r => r.GetCuentasSummaries())
                .Return(cuentasSummariesToExpect);

            // Act
            ViewResult result = cuentasController.Index().AssertViewRendered();

            // Assert
            result.ViewData.Model.ShouldNotBeNull();
            (result.ViewData.Model as IList<CuentasDto>).ShouldNotBeNull();
            (result.ViewData.Model as IList<CuentasDto>).Count.ShouldEqual(1);
        }

        [Test]
        public void CanShowCuentas() {
            // Establish Context
            Cuenta cuentas = 
                CuentasInstanceFactory.CreateValidTransientCuentas();

            cuentasManagementService.Expect(r => r.Get(1))
                .Return(cuentas);

            // Act
            ViewResult result = cuentasController.Show(1).AssertViewRendered();

            // Assert
            result.ViewData.Model.ShouldNotBeNull();
            (result.ViewData.Model as Cuenta).ShouldNotBeNull();
            (result.ViewData.Model as Cuenta).ShouldEqual(cuentas);
        }

        [Test]
        public void CanInitCreate() {
            // Establish Context
            CuentasFormViewModel viewModel = new CuentasFormViewModel();

            cuentasManagementService.Expect(r => r.CreateFormViewModel())
                .Return(viewModel);

            // Act
            ViewResult result = cuentasController.Create().AssertViewRendered();

            // Assert
            result.ViewData.Model.ShouldNotBeNull();
            (result.ViewData.Model as CuentasFormViewModel).ShouldNotBeNull();
            (result.ViewData.Model as CuentasFormViewModel).Cuentas.ShouldBeNull();
        }

        [Test]
        public void CanCreateValidCuentasFromForm() {
            // Establish Context
            Cuenta cuentasFromForm = new Cuenta();

            cuentasManagementService.Expect(r => r.SaveOrUpdate(cuentasFromForm))
                .Return(ActionConfirmation.CreateSuccessConfirmation("saved"));

            // Act
            RedirectToRouteResult redirectResult =
                cuentasController.Create(cuentasFromForm)
                .AssertActionRedirect().ToAction("Index");

            // Assert
            cuentasController.TempData[ControllerEnums.GlobalViewDataProperty.PageMessage.ToString()].ToString()
				.ShouldEqual("saved");
        }

        [Test]
        public void CannotCreateInvalidCuentasFromForm() {
            // Establish Context
            Cuenta cuentasFromForm = new Cuenta();
            CuentasFormViewModel viewModelToExpect = new CuentasFormViewModel();

            cuentasManagementService.Expect(r => r.SaveOrUpdate(cuentasFromForm))
                .Return(ActionConfirmation.CreateFailureConfirmation("not saved"));
            cuentasManagementService.Expect(r => r.CreateFormViewModelFor(cuentasFromForm))
                .Return(viewModelToExpect);

            // Act
            ViewResult result =
                cuentasController.Create(cuentasFromForm).AssertViewRendered();

            // Assert
            result.ViewData.Model.ShouldNotBeNull();
            (result.ViewData.Model as CuentasFormViewModel).ShouldNotBeNull();
        }

        [Test]
        public void CanInitEdit() {
            // Establish Context
            CuentasFormViewModel viewModel = new CuentasFormViewModel();

            cuentasManagementService.Expect(r => r.CreateFormViewModelFor(1))
                .Return(viewModel);

            // Act
            ViewResult result = cuentasController.Edit(1).AssertViewRendered();

            // Assert
            result.ViewData.Model.ShouldNotBeNull();
            (result.ViewData.Model as CuentasFormViewModel).ShouldNotBeNull();
        }

        [Test]
        public void CanUpdateValidCuentasFromForm() {
            // Establish Context
            Cuenta cuentasFromForm = new Cuenta();

            cuentasManagementService.Expect(r => r.UpdateWith(cuentasFromForm, 0))
                .Return(ActionConfirmation.CreateSuccessConfirmation("updated"));

            // Act
            RedirectToRouteResult redirectResult =
                cuentasController.Edit(cuentasFromForm)
                .AssertActionRedirect().ToAction("Index");

            // Assert
            cuentasController.TempData[ControllerEnums.GlobalViewDataProperty.PageMessage.ToString()].ToString()
                .ShouldEqual("updated");
        }

        [Test]
        public void CannotUpdateInvalidCuentasFromForm() {
            // Establish Context
            Cuenta cuentasFromForm = new Cuenta();
            CuentasFormViewModel viewModelToExpect = new CuentasFormViewModel();

            cuentasManagementService.Expect(r => r.UpdateWith(cuentasFromForm, 0))
                .Return(ActionConfirmation.CreateFailureConfirmation("not updated"));
            cuentasManagementService.Expect(r => r.CreateFormViewModelFor(cuentasFromForm))
                .Return(viewModelToExpect);

            // Act
            ViewResult result =
                cuentasController.Edit(cuentasFromForm).AssertViewRendered();

            // Assert
            result.ViewData.Model.ShouldNotBeNull();
            (result.ViewData.Model as CuentasFormViewModel).ShouldNotBeNull();
        }

        [Test]
        public void CanDeleteCuentas() {
            // Establish Context
            cuentasManagementService.Expect(r => r.Delete(1))
                .Return(ActionConfirmation.CreateSuccessConfirmation("deleted"));
            
            // Act
            RedirectToRouteResult redirectResult =
                cuentasController.Delete(1)
                .AssertActionRedirect().ToAction("Index");

            // Assert
            cuentasController.TempData[ControllerEnums.GlobalViewDataProperty.PageMessage.ToString()].ToString()
                .ShouldEqual("deleted");
        }

        private ICuentasManagementService cuentasManagementService;
        private CuentasController cuentasController;
    }
}
