﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HomeBanking.ApplicationServices;
using HomeBanking.Core;
using HomeBanking.Web.Controllers;
using MvcContrib.TestHelper;
using NUnit.Framework;
using Rhino.Mocks;

namespace Tests.HomeBanking.Web.Controllers
{
    [TestFixture]
    public class OperacionesControllerTest
    {
        OperacionesController controller;
        ITransferenciaService transferenciaService;

        [SetUp]
        public void Setup()
        {
            transferenciaService = MockRepository.GenerateMock<ITransferenciaService>();
            controller = new OperacionesController(transferenciaService);
        }

        [Test]
        public void Transfererir_RetornaVista()
        {
            controller.Transferir()
                .AssertViewRendered()
                .ModelShouldBe<DetallesTransferencia>(DetallesTransferencia.EMPTY);
        }


        [Test]
        public void Transferir_ParametrosValidos_RedireccionaConfirmacion()
        {
            controller.Transferir(null)
                .AssertActionRedirect()
                .ToAction<CuentasController>(c => c.Index());

        }

        [Test]
        public void Transferir_ParametrosValidos_LlamaServicioTransferencia()
        {
            DetallesTransferencia detallesTransferencia =
                    new DetallesTransferencia();

            controller.Transferir(detallesTransferencia);

            transferenciaService.AssertWasCalled(x => x.TransferirEnCuentaPersonal(detallesTransferencia));

        }
    }
}
