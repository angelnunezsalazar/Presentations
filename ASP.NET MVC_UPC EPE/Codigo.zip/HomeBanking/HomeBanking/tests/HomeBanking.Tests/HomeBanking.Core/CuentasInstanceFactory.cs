using System;
using HomeBanking.Core;

namespace Tests.HomeBanking.Core
{
    public class CuentasInstanceFactory
    {
        public static Cuenta CreateValidTransientCuentas() {
            return new Cuenta() {
			    Numero = "1234-6789-5678", 
				Saldo = 500 
            };
        }
    }
}
