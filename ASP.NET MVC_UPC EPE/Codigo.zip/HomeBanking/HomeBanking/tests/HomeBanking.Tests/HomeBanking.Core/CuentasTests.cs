using NUnit.Framework;
using SharpArch.Testing;
using SharpArch.Testing.NUnit;
using HomeBanking.Core;

namespace Tests.HomeBanking.Core
{
	[TestFixture]
    public class CuentasTests
    {
        [Test]
        public void CanCompareCuentas() {
            Cuenta instance = new Cuenta();
			instance.Numero = "1234-6789-5678";

            Cuenta instanceToCompareTo = new Cuenta();
			instanceToCompareTo.Numero = "1234-6789-5678";

			instance.ShouldEqual(instanceToCompareTo);
        }

        [Test]
        public void Depositar_MontoValido_SaldoSeHaIncrementado()
        {
            int monto = 300;
            int saldo = 200;
            Cuenta cuenta = CrearCuenta("1234-6789-5678");
            cuenta.Depositar(saldo);

            cuenta.Depositar(monto);

            Assert.AreEqual(cuenta.Saldo, saldo + monto);

        }

        [Test]
        public void Transferir_MontoValido_ElSaldoDeLaSegundaCuentaSeHaIncrementado()
        {
            Cuenta cuentaOrigen = CrearCuenta("1234-6789-5678");
            cuentaOrigen.Depositar(200);
            Cuenta cuentaDestino = CrearCuenta("2345-6789-5678");
            cuentaDestino.Depositar(200);

            cuentaOrigen.Transferir(100, cuentaDestino);

            Assert.AreEqual(300, cuentaDestino.Saldo);

        }

        [Test]
        public void Transferir_MontoValido_ElSaldoDeLaCuentaOrigenSeHaDisminuido()
        {
            Cuenta cuentaOrigen = CrearCuenta("1234-6789-5678");
            cuentaOrigen.Depositar(200);
            Cuenta cuentaDestino = CrearCuenta("2345-6789-5678");
            cuentaDestino.Depositar(200);

            cuentaOrigen.Transferir(100, cuentaDestino);

            Assert.AreEqual(100, cuentaOrigen.Saldo);

        }

        private static Cuenta CrearCuenta(string numero)
        {
            return new Cuenta() { Numero = numero };
        }
    }
}
