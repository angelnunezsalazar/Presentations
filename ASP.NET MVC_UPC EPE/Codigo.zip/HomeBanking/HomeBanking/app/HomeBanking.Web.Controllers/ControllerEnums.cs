﻿namespace HomeBanking.Web.Controllers
{
    public class ControllerEnums
    {
        public enum GlobalViewDataProperty
        {
            PageMessage
        }
    }
}
