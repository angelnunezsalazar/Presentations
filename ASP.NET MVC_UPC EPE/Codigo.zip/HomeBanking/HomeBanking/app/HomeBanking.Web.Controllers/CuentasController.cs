using System.Web.Mvc;
using SharpArch.Core.PersistenceSupport;
using SharpArch.Core.DomainModel;
using System.Collections.Generic;
using SharpArch.Web.NHibernate;
using NHibernate.Validator.Engine;
using System.Text;
using SharpArch.Web.CommonValidator;
using SharpArch.Core;
using HomeBanking.Core;
using HomeBanking.ApplicationServices;
using HomeBanking.ApplicationServices.ViewModels;
using HomeBanking.Core.QueryDtos;
using HomeBanking.Core.RepositoryInterfaces;
 

namespace HomeBanking.Web.Controllers
{
    [HandleError]
    public class CuentasController : Controller
    {
        public CuentasController(ICuentasManagementService cuentasManagementService) {
            Check.Require(cuentasManagementService != null, "cuentasManagementService may not be null");

            this.cuentasManagementService = cuentasManagementService;
        }

        [Transaction]
        public ActionResult Index() {
            IList<CuentasDto> cuentas = 
                cuentasManagementService.GetCuentasSummaries();
            return View(cuentas);
        }

        [Transaction]
        public ActionResult Show(int id) {
            Cuenta cuentas = cuentasManagementService.Get(id);
            return View(cuentas);
        }

        [Transaction]
        public ActionResult Create() {
            CuentasFormViewModel viewModel = 
                cuentasManagementService.CreateFormViewModel();
            return View(viewModel);
        }

        [ValidateAntiForgeryToken]
        [Transaction]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(Cuenta cuentas) {
            if (ViewData.ModelState.IsValid) {
                ActionConfirmation saveOrUpdateConfirmation = 
                    cuentasManagementService.SaveOrUpdate(cuentas);

                if (saveOrUpdateConfirmation.WasSuccessful) {
                    TempData[ControllerEnums.GlobalViewDataProperty.PageMessage.ToString()] = 
                        saveOrUpdateConfirmation.Message;
                    return RedirectToAction("Index");
                }
            } else {
                cuentas = null;
            }

            CuentasFormViewModel viewModel = 
                cuentasManagementService.CreateFormViewModelFor(cuentas);
            return View(viewModel);
        }

        [Transaction]
        public ActionResult Edit(int id) {
            CuentasFormViewModel viewModel = 
                cuentasManagementService.CreateFormViewModelFor(id);
            return View(viewModel);
        }

        [ValidateAntiForgeryToken]
        [Transaction]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(Cuenta cuentas) {
            if (ViewData.ModelState.IsValid) {
                ActionConfirmation updateConfirmation = 
                    cuentasManagementService.UpdateWith(cuentas, cuentas.Id);

                if (updateConfirmation.WasSuccessful) {
                    TempData[ControllerEnums.GlobalViewDataProperty.PageMessage.ToString()] = 
                        updateConfirmation.Message;
                    return RedirectToAction("Index");
                }
            }

            CuentasFormViewModel viewModel = 
                cuentasManagementService.CreateFormViewModelFor(cuentas);
            return View(viewModel);
        }

        [ValidateAntiForgeryToken]
        [Transaction]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Delete(int id) {
            ActionConfirmation deleteConfirmation = cuentasManagementService.Delete(id);
            TempData[ControllerEnums.GlobalViewDataProperty.PageMessage.ToString()] = 
                deleteConfirmation.Message;
            return RedirectToAction("Index");
        }

        private readonly ICuentasManagementService cuentasManagementService;
    }
}
