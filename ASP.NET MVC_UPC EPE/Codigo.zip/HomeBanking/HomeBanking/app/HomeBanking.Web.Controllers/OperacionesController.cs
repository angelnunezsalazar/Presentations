﻿using System.Web.Mvc;
using HomeBanking.ApplicationServices;
using HomeBanking.Core;
using SharpArch.Web.NHibernate;
using MvcContrib;

namespace HomeBanking.Web.Controllers
{
 public class OperacionesController : Controller
    {
        private ITransferenciaService Transferencia { get; set; }

        public OperacionesController(ITransferenciaService transferenciaService)
        {
            Transferencia = transferenciaService;
        }

        [HttpGet]
        public ViewResult Transferir()
        {
            return View(DetallesTransferencia.EMPTY);
        }

        [HttpPost]
        [Transaction]
        public ActionResult Transferir(DetallesTransferencia detallesTransferencia)
        {
            if (ViewData.ModelState.IsValid)
            {
                Transferencia.TransferirEnCuentaPersonal(detallesTransferencia);
                return this.RedirectToAction<CuentasController>(x => x.Index());
            }
            return View(detallesTransferencia);
            
        }
    }
}
