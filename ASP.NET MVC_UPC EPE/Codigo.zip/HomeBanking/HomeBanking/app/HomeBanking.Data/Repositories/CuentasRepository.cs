using System;
using System.Linq;
using System.Threading;
using SharpArch.Data.NHibernate;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Transform;
using HomeBanking.Core;
using HomeBanking.Core.QueryDtos;
using HomeBanking.Core.RepositoryInterfaces;
using NHibernate.Linq;


namespace HomeBanking.Data.Repositories
{
    public class CuentaRepository : Repository<Cuenta>, ICuentaRepository
    {
        public IList<CuentasDto> GetCuentasSummaries()
        {
            ISession session = SharpArch.Data.NHibernate.NHibernateSession.Current;

            IQuery query = session.GetNamedQuery("GetCuentasSummaries")
                .SetResultTransformer(Transformers.AliasToBean<CuentasDto>());

            return query.List<CuentasDto>();
        }

        public Cuenta Obtener(string numero)
        {
            var cuenta = from c in Session.Linq<Cuenta>()
                         where c.Numero == numero
                         select c;
            return cuenta.SingleOrDefault();
        }
    }
}
