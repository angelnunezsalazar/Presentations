using HomeBanking.Core;

namespace HomeBanking.ApplicationServices.ViewModels
{
    public class CuentasFormViewModel
    {
        public Cuenta Cuentas { get; set; }
    }
}
