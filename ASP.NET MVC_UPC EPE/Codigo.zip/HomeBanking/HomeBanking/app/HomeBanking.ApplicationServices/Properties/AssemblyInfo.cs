﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("HomeBanking.ApplicationServices")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("HomeBanking.ApplicationServices")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("31b8d81a-5b3e-466b-bf37-50f55280aaf4")]
