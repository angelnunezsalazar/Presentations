using System.Collections.Generic;
using HomeBanking.Core;
using HomeBanking.ApplicationServices.ViewModels;
using HomeBanking.Core.QueryDtos;
 

namespace HomeBanking.ApplicationServices
{
    public interface ICuentasManagementService
    {
        CuentasFormViewModel CreateFormViewModel();
        CuentasFormViewModel CreateFormViewModelFor(int cuentasId);
        CuentasFormViewModel CreateFormViewModelFor(Cuenta cuentas);
        Cuenta Get(int id);
        IList<Cuenta> GetAll();
        IList<CuentasDto> GetCuentasSummaries();
        ActionConfirmation SaveOrUpdate(Cuenta cuentas);
        ActionConfirmation UpdateWith(Cuenta cuentasFromForm, int idOfCuentasToUpdate);
        ActionConfirmation Delete(int id);
    }
}
