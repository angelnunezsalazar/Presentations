﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HomeBanking.Core;
using HomeBanking.Core.RepositoryInterfaces;

namespace HomeBanking.ApplicationServices
{
    public interface ITransferenciaService
    {
        void TransferirEnCuentaPersonal(DetallesTransferencia detalles);
    }

    public class TransferenciaService : ITransferenciaService
    {
        private ICuentaRepository Cuentas { get; set; }

        public TransferenciaService(ICuentaRepository cuentaRepository)
        {
            Cuentas = cuentaRepository;
        }

        public void TransferirEnCuentaPersonal(DetallesTransferencia detalles)
        {
            var cuentaOrigen = Cuentas.Obtener(detalles.NumeroCuentaOrigen);
            var cuentaDestino = Cuentas.Obtener(detalles.NumeroCuentaDestino);
            cuentaOrigen.Transferir(detalles.Monto, cuentaDestino);
        }
    }
}
