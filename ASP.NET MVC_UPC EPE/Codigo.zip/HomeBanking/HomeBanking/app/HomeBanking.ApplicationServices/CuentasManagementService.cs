using System.Collections.Generic;
using System;
using SharpArch.Core;
using HomeBanking.Core;
using HomeBanking.ApplicationServices.ViewModels;
using HomeBanking.Core.QueryDtos;
using HomeBanking.Core.RepositoryInterfaces;
 

namespace HomeBanking.ApplicationServices
{
    public class CuentasManagementService : ICuentasManagementService
    {
        public CuentasManagementService(ICuentaRepository cuentasRepository) {
            Check.Require(cuentasRepository != null, "cuentasRepository may not be null");

            this.cuentasRepository = cuentasRepository;
        }

        public Cuenta Get(int id) {
            return cuentasRepository.Get(id);
        }

        public IList<Cuenta> GetAll() {
            return cuentasRepository.GetAll();
        }

        public IList<CuentasDto> GetCuentasSummaries() {
            return cuentasRepository.GetCuentasSummaries();
        }

        public CuentasFormViewModel CreateFormViewModel() {
            CuentasFormViewModel viewModel = new CuentasFormViewModel();
            return viewModel;
        }

        public CuentasFormViewModel CreateFormViewModelFor(int cuentasId) {
            Cuenta cuentas = cuentasRepository.Get(cuentasId);
            return CreateFormViewModelFor(cuentas);
        }

        public CuentasFormViewModel CreateFormViewModelFor(Cuenta cuentas) {
            CuentasFormViewModel viewModel = CreateFormViewModel();
            viewModel.Cuentas = cuentas;
            return viewModel;
        }

        public ActionConfirmation SaveOrUpdate(Cuenta cuentas) {
            if (cuentas.IsValid()) {
                cuentasRepository.SaveOrUpdate(cuentas);

                ActionConfirmation saveOrUpdateConfirmation = ActionConfirmation.CreateSuccessConfirmation(
                    "The cuentas was successfully saved.");
                saveOrUpdateConfirmation.Value = cuentas;

                return saveOrUpdateConfirmation;
            }
            else {
                cuentasRepository.DbContext.RollbackTransaction();

                return ActionConfirmation.CreateFailureConfirmation(
                    "The cuentas could not be saved due to missing or invalid information.");
            }
        }

        public ActionConfirmation UpdateWith(Cuenta cuentasFromForm, int idOfCuentasToUpdate) {
            Cuenta cuentasToUpdate = 
                cuentasRepository.Get(idOfCuentasToUpdate);
            TransferFormValuesTo(cuentasToUpdate, cuentasFromForm);

            if (cuentasToUpdate.IsValid()) {
                ActionConfirmation updateConfirmation = ActionConfirmation.CreateSuccessConfirmation(
                    "The cuentas was successfully updated.");
                updateConfirmation.Value = cuentasToUpdate;

                return updateConfirmation;
            }
            else {
                cuentasRepository.DbContext.RollbackTransaction();

                return ActionConfirmation.CreateFailureConfirmation(
                    "The cuentas could not be saved due to missing or invalid information.");
            }
        }

        public ActionConfirmation Delete(int id) {
            Cuenta cuentasToDelete = cuentasRepository.Get(id);

            if (cuentasToDelete != null) {
                cuentasRepository.Delete(cuentasToDelete);

                try {
                    cuentasRepository.DbContext.CommitChanges();
                    
                    return ActionConfirmation.CreateSuccessConfirmation(
                        "The cuentas was successfully deleted.");
                }
                catch {
                    cuentasRepository.DbContext.RollbackTransaction();

                    return ActionConfirmation.CreateFailureConfirmation(
                        "A problem was encountered preventing the cuentas from being deleted. " +
                        "Another item likely depends on this cuentas.");
                }
            }
            else {
                return ActionConfirmation.CreateFailureConfirmation(
                    "The cuentas could not be found for deletion. It may already have been deleted.");
            }
        }

        private void TransferFormValuesTo(Cuenta cuentasToUpdate, Cuenta cuentasFromForm) {
		    cuentasToUpdate.Numero = cuentasFromForm.Numero;
			cuentasToUpdate.Saldo = cuentasFromForm.Saldo;
        }

        ICuentaRepository cuentasRepository;
    }
}
