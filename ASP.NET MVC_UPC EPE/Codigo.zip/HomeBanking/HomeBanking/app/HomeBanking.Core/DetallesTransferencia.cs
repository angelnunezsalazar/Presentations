﻿using System.ComponentModel.DataAnnotations;

namespace HomeBanking.Core
{
    public class DetallesTransferencia
    {
        public static readonly DetallesTransferencia EMPTY =
            new DetallesTransferencia()
                {
                    NumeroCuentaDestino = string.Empty,
                    NumeroCuentaOrigen = string.Empty,
                    Monto = 0
                };

        [Required(ErrorMessage = "Cuenta Origen es obligatoria")]
        public string NumeroCuentaOrigen { get; set; }

        [Required(ErrorMessage = "Cuenta Destino es obligatoria")]
        public string NumeroCuentaDestino { get; set; }

        [Range(10,100,ErrorMessage = "Cuenta Origen es obligatoria")]
        public int Monto { get; set; }
    }
}
