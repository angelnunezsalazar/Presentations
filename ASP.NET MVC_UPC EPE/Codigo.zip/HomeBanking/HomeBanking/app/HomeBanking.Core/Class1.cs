namespace HomeBanking.Core
{
    /// <summary>
    /// This is a placeholder class so that HomeBanking.Data.NHibernateMaps.AutoPersistenceModelGenerator 
    /// can reference this assembly.  Feel free to delete this class and point AutoPersistenceModelGenerator
    /// to any other class within this assembly.
    /// </summary>
    public class Class1
    {
    }
}
