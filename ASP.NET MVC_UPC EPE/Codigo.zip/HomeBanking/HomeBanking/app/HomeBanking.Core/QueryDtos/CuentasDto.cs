using System;

namespace HomeBanking.Core.QueryDtos
{
    public class CuentasDto
    {
        public int Id { get; set; }
		public string Numero { get; set; }
		public int Saldo { get; set; }
    }
}
