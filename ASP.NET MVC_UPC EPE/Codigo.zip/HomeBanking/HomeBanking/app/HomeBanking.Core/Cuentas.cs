using System;
using NHibernate.Validator.Constraints;
using SharpArch.Core.DomainModel;

namespace HomeBanking.Core
{
    public class Cuenta : Entity
    {
		[DomainSignature]
		[NotNull, NotEmpty]
		public virtual string Numero { get; set; }

		public virtual int Saldo { get; set; }        
        
        public virtual void Depositar(int monto)
        {
            Saldo = Saldo + monto;
        }

        public virtual void Transferir(int monto, Cuenta cuentaDestino)
        {
            Saldo = Saldo - monto;
            cuentaDestino.Depositar(monto);
        }
    }
}
