using SharpArch.Core.PersistenceSupport;
using System.Collections.Generic;
using HomeBanking.Core;
using HomeBanking.Core.QueryDtos;

namespace HomeBanking.Core.RepositoryInterfaces
{
    public interface ICuentaRepository : IRepository<Cuenta>
    {
        IList<CuentasDto> GetCuentasSummaries();
        Cuenta Obtener(string numero);
    }
}
