// Type: System.Web.Routing.RouteTable
// Assembly: System.Web.Routing, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// Assembly location: C:\Users\Snahider\Documents\Visual Studio 2010\Projects\HomeBanking\HomeBanking\lib\System.Web.Routing.dll

namespace System.Web.Routing
{
    public class RouteTable
    {
        public RouteTable();
        public static RouteCollection Routes { get; }
    }
}
